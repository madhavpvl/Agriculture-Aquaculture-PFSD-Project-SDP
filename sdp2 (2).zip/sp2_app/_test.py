def test_area():
    output=algo.area_of_rectangle(2,5)
assert output==10
def test_perimeer():
    output=algo.perimeter_of_rectangle(2,5)
asser output
